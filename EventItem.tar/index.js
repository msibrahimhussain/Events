import './index.css'

const EventItem = props => {
  const {eventDetails} = props
  const {registrationStatus, name, location, imageUrl, onClkImg} = eventDetails

  const onClk = () => {
    onClkImg(registrationStatus)
  }

  return (
    <li>
      <button type="button" onClick={onClk}>
        <img src={imageUrl} alt="event" className="i" />
      </button>
      <p>{name}</p>
      <p>{location}</p>
      <p>{registrationStatus}</p>
    </li>
  )
}

export default EventItem
