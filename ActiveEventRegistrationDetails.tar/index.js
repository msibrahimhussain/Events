import {Component} from 'react'
import './index.css'

class ActiveEventRegistrationDetails extends Component {
  renderInitial = () => (
    <p>Click on an event, to view its registration details</p>
  )

  renderYet = () => (
    <div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-register-img.png"
        alt="yet to register"
        className="sts-i"
      />
      <p>A live performance brings so much to your relationship with dance</p>
      <button type="button">Register Here</button>
    </div>
  )

  renderClosed = () => (
    <div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-registrations-closed-img.png"
        alt="registrations closed"
        className="sts-i"
      />
      <h1>Registrations Are Closed Now!</h1>
      <p>Stay tuned. We will reopen</p>
    </div>
  )

  renderRegistered = () => (
    <div>
      <img
        src="https://assets.ccbp.in/frontend/react-js/events-regestered-img.png"
        alt="registered"
        className="sts-i"
      />
      <h1>You have already registered fot the event</h1>
    </div>
  )

  render() {
    const {sts} = this.props
    // console.log(sts)
    switch (sts) {
      case 'INITIAL':
        return this.renderInitial()
      case 'REGISTRATIONS_CLOSED':
        return this.renderClosed()
      case 'YET_TO_REGISTER':
        return this.renderYet()
      case 'REGISTERED':
        return this.renderRegistered()
      default:
        return <h1>NotFound</h1>
    }
  }
}

export default ActiveEventRegistrationDetails
